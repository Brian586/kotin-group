

:root{
    --base-h: 255;
    --base-s: 77%;
    --base-l: 57%;
} 